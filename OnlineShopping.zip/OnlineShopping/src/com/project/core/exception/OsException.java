package com.project.core.exception;

public class OsException extends Exception {

	public OsException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public OsException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public OsException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}
