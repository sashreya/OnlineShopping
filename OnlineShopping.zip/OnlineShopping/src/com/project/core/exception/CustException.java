package com.project.core.exception;

public class CustException extends Exception {

	public CustException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public CustException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CustException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
